from django.contrib import admin
from .models import ArtPiece

admin.site.register(ArtPiece)
